
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { ResultDisplay } from './components/ResultDisplay';
import { Button } from './components/Button';
import { removeBackground, enhanceFace } from './services/geminiService';

export default function App() {
  const [originalFile, setOriginalFile] = useState<File | null>(null);
  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
  const [processedImageUrl, setProcessedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isEnhancing, setIsEnhancing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [isTouchUpActive, setIsTouchUpActive] = useState<boolean>(false);

  const handleResetAdjustments = useCallback(() => {
    setBrightness(100);
    setContrast(100);
  }, []);

  const handleFileSelect = (file: File) => {
    setOriginalFile(file);
    setOriginalImageUrl(URL.createObjectURL(file));
    setProcessedImageUrl(null);
    setError(null);
  };

  const handleRemoveBackground = useCallback(async () => {
    if (!originalFile) {
      setError("Please select an image first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setProcessedImageUrl(null);

    const reader = new FileReader();
    reader.readAsDataURL(originalFile);
    reader.onloadend = async () => {
      try {
        const base64WithPrefix = reader.result as string;
        const base64Data = base64WithPrefix.split(',')[1];
        const mimeType = originalFile.type;
        
        const resultBase64 = await removeBackground(base64Data, mimeType);
        setProcessedImageUrl(`data:image/png;base64,${resultBase64}`);
        handleResetAdjustments();
      } catch (err) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError("An unknown error occurred.");
        }
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
      setError("Failed to read the selected file.");
      setIsLoading(false);
    }
  }, [originalFile, handleResetAdjustments]);

  const handleEnhanceFace = useCallback(async () => {
    if (!processedImageUrl) {
      setError("No processed image to enhance.");
      return;
    }

    setIsEnhancing(true);
    setError(null);

    try {
      const mimeType = processedImageUrl.substring(processedImageUrl.indexOf(":") + 1, processedImageUrl.indexOf(";"));
      const base64Data = processedImageUrl.split(',')[1];
      
      const resultBase64 = await enhanceFace(base64Data, mimeType);
      setProcessedImageUrl(`data:image/png;base64,${resultBase64}`);
      handleResetAdjustments();
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred during face enhancement.");
      }
    } finally {
      setIsEnhancing(false);
    }
  }, [processedImageUrl, handleResetAdjustments]);

  const handleToggleTouchUp = useCallback(() => {
    setIsTouchUpActive(prev => !prev);
  }, []);

  const handleApplyTouchUp = useCallback((newImageDataUrl: string) => {
    setProcessedImageUrl(newImageDataUrl);
    setIsTouchUpActive(false);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 md:p-8">
      <Header />
      <main className="w-full max-w-6xl mx-auto flex flex-col items-center flex-grow">
        <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
          <ImageUploader onFileSelect={handleFileSelect} imageUrl={originalImageUrl} />
          <ResultDisplay 
            imageUrl={processedImageUrl} 
            isLoading={isLoading} 
            isEnhancing={isEnhancing}
            error={error}
            brightness={brightness}
            contrast={contrast}
            onBrightnessChange={setBrightness}
            onContrastChange={setContrast}
            onResetAdjustments={handleResetAdjustments}
            onEnhanceFace={handleEnhanceFace}
            isTouchUpActive={isTouchUpActive}
            onToggleTouchUp={handleToggleTouchUp}
            onApplyTouchUp={handleApplyTouchUp}
          />
        </div>
        <div className="mt-8 w-full max-w-sm">
          <Button
            onClick={handleRemoveBackground}
            disabled={!originalFile || isLoading}
          >
            {isLoading ? "Processing..." : "Remove Background"}
          </Button>
          {error && !isLoading && <p className="text-red-400 text-center mt-4">{error}</p>}
        </div>
      </main>
      <footer className="text-center p-4 mt-8 text-gray-500 text-sm">
        <p>Powered by Gemini. Built with React & Tailwind CSS.</p>
      </footer>
    </div>
  );
}
