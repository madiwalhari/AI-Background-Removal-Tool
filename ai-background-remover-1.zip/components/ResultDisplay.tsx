
import React, { useCallback } from 'react';
import { Loader } from './Loader';
import { Button } from './Button';
import { DownloadIcon, ResetIcon, FaceIcon, PassportIcon, StampIcon, PaintBrushIcon } from './icons';
import { AdjustmentSlider } from './AdjustmentSlider';
import { InteractiveCanvasEditor } from './InteractiveCanvasEditor';

interface ResultDisplayProps {
  imageUrl: string | null;
  isLoading: boolean;
  isEnhancing: boolean;
  error: string | null;
  brightness: number;
  contrast: number;
  onBrightnessChange: (value: number) => void;
  onContrastChange: (value: number) => void;
  onResetAdjustments: () => void;
  onEnhanceFace: () => void;
  isTouchUpActive: boolean;
  onToggleTouchUp: () => void;
  onApplyTouchUp: (imageDataUrl: string) => void;
}

const checkerboardBg = `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' size='16' fill-opacity='0.1'%3e%3cpath d='M0 0h16v16H0z' fill='%23fff'/%3e%3cpath d='M16 16h16v16H16z' fill='%23fff'/%3e%3c/svg%3e")`;

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ 
  imageUrl, 
  isLoading, 
  isEnhancing,
  error,
  brightness,
  contrast,
  onBrightnessChange,
  onContrastChange,
  onResetAdjustments,
  onEnhanceFace,
  isTouchUpActive,
  onToggleTouchUp,
  onApplyTouchUp,
}) => {

  const handleDownload = useCallback((options?: { width?: number; height?: number; filename?: string }) => {
    if (!imageUrl) return;

    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.onload = () => {
        const canvas = document.createElement('canvas');
        
        const targetWidth = options?.width || image.naturalWidth;
        const targetHeight = options?.height || image.naturalHeight;
        
        canvas.width = targetWidth;
        canvas.height = targetHeight;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;

        if (options?.width && options?.height) {
            const sourceWidth = image.naturalWidth;
            const sourceHeight = image.naturalHeight;
            const sourceAspectRatio = sourceWidth / sourceHeight;
            const targetAspectRatio = targetWidth / targetHeight;

            let sWidth = sourceWidth;
            let sHeight = sourceHeight;
            let sx = 0;
            let sy = 0;

            if (sourceAspectRatio > targetAspectRatio) {
                sWidth = sourceHeight * targetAspectRatio;
                sx = (sourceWidth - sWidth) / 2;
            } else if (sourceAspectRatio < targetAspectRatio) {
                sHeight = sourceWidth / targetAspectRatio;
                sy = (sourceHeight - sHeight) / 2;
            }
            
            if (options.filename?.includes('passport-photo') && sy > 0) {
                sy = (sourceHeight - sHeight) * 0.25;
            }
            
            ctx.drawImage(image, sx, sy, sWidth, sHeight, 0, 0, targetWidth, targetHeight);
        } else {
            ctx.drawImage(image, 0, 0, targetWidth, targetHeight);
        }

        const link = document.createElement('a');
        link.download = options?.filename || 'background-removed.png';
        link.href = canvas.toDataURL('image/png');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    image.src = imageUrl;
  }, [imageUrl, brightness, contrast]);


  return (
    <div className="w-full flex flex-col items-center">
      <h2 className="text-2xl font-bold text-gray-300 mb-4">Processed Image</h2>
      <div 
        className="w-full aspect-square bg-gray-800 rounded-2xl shadow-lg flex items-center justify-center relative overflow-hidden"
        style={{ backgroundImage: checkerboardBg }}
      >
        {isLoading && <Loader message="Removing background..." />}
        {isEnhancing && (
            <div className="absolute inset-0 bg-gray-900 bg-opacity-75 flex flex-col items-center justify-center z-20 transition-opacity duration-300">
                <Loader message="Enhancing face..." />
            </div>
        )}
        {!isLoading && error && (
          <div className="text-center p-4 text-red-400">
            <p className="font-semibold">Processing Failed</p>
            <p className="text-sm mt-1">{error}</p>
          </div>
        )}
        {!isLoading && !error && imageUrl && (
          <img 
            src={imageUrl} 
            alt="Processed" 
            className="max-w-full max-h-full object-contain z-10" 
            style={{ 
                filter: `brightness(${brightness}%) contrast(${contrast}%)`,
                opacity: isEnhancing ? 0.5 : 1,
                transition: 'opacity 300ms ease-in-out',
            }}
          />
        )}
        {!isLoading && !error && !imageUrl && (
            <div className="text-center text-gray-500 p-4">
                <p className="font-semibold">Your result will appear here</p>
            </div>
        )}
      </div>

      {imageUrl && !isLoading && !error && isTouchUpActive && (
        <InteractiveCanvasEditor 
          imageUrl={imageUrl}
          onApply={onApplyTouchUp}
          onCancel={onToggleTouchUp}
        />
      )}
      
      {imageUrl && !isLoading && !error && (
        <div className="w-full mt-6 p-4 bg-gray-800 rounded-2xl shadow-lg space-y-4">
          <AdjustmentSlider
              label="Brightness"
              value={brightness}
              onChange={onBrightnessChange}
          />
          <AdjustmentSlider
              label="Contrast"
              value={contrast}
              onChange={onContrastChange}
          />

          <div className="pt-2">
            <h3 className="text-sm font-medium text-gray-400 text-center mb-3">Editing Tools</h3>
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={onEnhanceFace} disabled={isEnhancing}>
                {isEnhancing ? (
                  'Enhancing...'
                ) : (
                  <>
                    <FaceIcon className="h-5 w-5 mr-2" />
                    Enhance Face
                  </>
                )}
              </Button>
              <Button onClick={onToggleTouchUp} variant="secondary">
                <PaintBrushIcon className="h-5 w-5 mr-2" />
                Touch Up
              </Button>
            </div>
          </div>

          <div className="pt-2">
            <h3 className="text-sm font-medium text-gray-400 text-center mb-3">Download As</h3>
            <div className="grid grid-cols-3 gap-3">
              <Button onClick={() => handleDownload({ filename: 'original.png' })} variant="secondary" size="small">
                <DownloadIcon className="h-4 w-4 mr-1.5" />
                Original
              </Button>
              <Button onClick={() => handleDownload({ width: 600, height: 600, filename: 'passport-photo.png' })} variant="secondary" size="small">
                <PassportIcon className="h-4 w-4 mr-1.5" />
                Passport
              </Button>
              <Button onClick={() => handleDownload({ width: 236, height: 295, filename: 'stamp-photo.png' })} variant="secondary" size="small">
                <StampIcon className="h-4 w-4 mr-1.5" />
                Stamp
              </Button>
            </div>
          </div>
          
          <div className="pt-2">
            <Button onClick={onResetAdjustments} variant="secondary">
                <ResetIcon className="h-5 w-5 mr-2" />
                Reset
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
