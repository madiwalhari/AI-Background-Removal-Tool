
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { AdjustmentSlider } from './AdjustmentSlider';
import { Button } from './Button';
import { ZoomInIcon, ZoomOutIcon, ZoomFitIcon } from './icons';

interface InteractiveCanvasEditorProps {
  imageUrl: string;
  onApply: (imageDataUrl: string) => void;
  onCancel: () => void;
}

type BrushMode = 'smooth' | 'clarify';

export const InteractiveCanvasEditor: React.FC<InteractiveCanvasEditorProps> = ({ imageUrl, onApply, onCancel }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sourceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const tempCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const tempBlurCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const strokeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushSize, setBrushSize] = useState(30);
  const [brushStrength, setBrushStrength] = useState(10);
  const [brushOpacity, setBrushOpacity] = useState(100);
  const [blur, setBlur] = useState(0);
  const [brushMode, setBrushMode] = useState<BrushMode>('clarify');

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const lastPanPoint = useRef({ x: 0, y: 0 });
  const [isSpacePressed, setIsSpacePressed] = useState(false);

  // Initialize helper canvases once
  useEffect(() => {
    tempCanvasRef.current = document.createElement('canvas');
    tempBlurCanvasRef.current = document.createElement('canvas');
    strokeCanvasRef.current = document.createElement('canvas');
  }, []);

  // Spacebar listener for panning
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        setIsSpacePressed(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        setIsSpacePressed(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);


  const drawImageOnCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.src = imageUrl;
    image.onload = () => {
      const canvasContainer = canvas.parentElement?.parentElement;
      if (!canvasContainer) return;
      const { width: containerWidth, height: containerHeight } = canvasContainer.getBoundingClientRect();

      const imageAspectRatio = image.naturalWidth / image.naturalHeight;
      const containerAspectRatio = containerWidth / containerHeight;

      let renderWidth = containerWidth;
      let renderHeight = containerHeight;

      if (imageAspectRatio > containerAspectRatio) {
        renderHeight = containerWidth / imageAspectRatio;
      } else {
        renderWidth = containerHeight * imageAspectRatio;
      }
      
      canvas.width = renderWidth;
      canvas.height = renderHeight;

      if (!sourceCanvasRef.current) {
        sourceCanvasRef.current = document.createElement('canvas');
      }
      sourceCanvasRef.current.width = renderWidth;
      sourceCanvasRef.current.height = renderHeight;
      const sourceCtx = sourceCanvasRef.current.getContext('2d');

      if (ctx) {
        ctx.filter = `blur(${blur}px)`;
        ctx.drawImage(image, 0, 0, renderWidth, renderHeight);
      }
      
      sourceCtx?.drawImage(image, 0, 0, renderWidth, renderHeight);
    };
  }, [imageUrl, blur]);

  useEffect(() => {
    drawImageOnCanvas();
    window.addEventListener('resize', drawImageOnCanvas);
    return () => {
        window.removeEventListener('resize', drawImageOnCanvas);
    }
  }, [drawImageOnCanvas]);

  const getCanvasCoordinates = (nativeEvent: MouseEvent | Touch) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();

    // Convert screen coordinates to coordinates on the canvas's bitmap
    // by accounting for the CSS transform (scale and translate).
    return {
      x: (nativeEvent.clientX - rect.left) / zoom,
      y: (nativeEvent.clientY - rect.top) / zoom,
    };
  };

  const draw = useCallback((nativeEvent: MouseEvent | Touch) => {
    if (!isDrawing) return;
    const coords = getCanvasCoordinates(nativeEvent);
    const canvas = canvasRef.current;
    const sourceCanvas = sourceCanvasRef.current;
    if (!coords || !canvas || !sourceCanvas) return;

    const { x, y } = coords;

    // Use an off-screen canvas to prepare the brush stroke before drawing to the main canvas.
    // This allows us to handle opacity, shape, and effect cleanly.
    const strokeCanvas = strokeCanvasRef.current;
    if (!strokeCanvas) return;
    const strokeCtx = strokeCanvas.getContext('2d');
    if (!strokeCtx) return;

    // `brushSize` is the diameter in screen pixels.
    // Calculate the diameter and radius on the canvas's coordinate system.
    const brushDiameterOnCanvas = brushSize / zoom;
    const brushRadiusOnCanvas = brushDiameterOnCanvas / 2;
    
    // Area to grab from source image
    const sx = x - brushRadiusOnCanvas;
    const sy = y - brushRadiusOnCanvas;
    const sWidth = brushDiameterOnCanvas;
    const sHeight = brushDiameterOnCanvas;
    
    strokeCanvas.width = sWidth;
    strokeCanvas.height = sHeight;
    strokeCtx.clearRect(0, 0, sWidth, sHeight);

    // STEP 1: Apply the selected effect (smooth/clarify) from the source image
    // to our off-screen stroke canvas.
    if (brushMode === 'smooth') {
      strokeCtx.filter = `blur(${brushStrength}px)`;
      strokeCtx.drawImage(sourceCanvas, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);
    } else if (brushMode === 'clarify') {
      const tempCanvas = tempCanvasRef.current;
      const tempBlurCanvas = tempBlurCanvasRef.current;
      if (!tempCanvas || !tempBlurCanvas) return;
      
      const tempCtx = tempCanvas.getContext('2d');
      const tempBlurCtx = tempBlurCanvas.getContext('2d');
      if (!tempCtx || !tempBlurCtx) return;

      tempCanvas.width = sWidth;
      tempCanvas.height = sHeight;
      tempBlurCanvas.width = sWidth;
      tempBlurCanvas.height = sHeight;

      // Copy the source area to a temporary canvas
      tempCtx.drawImage(sourceCanvas, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);

      // Create a blurred version for the low-frequency layer (color/tone)
      const blurRadius = Math.max(5, brushRadiusOnCanvas / 4);
      tempBlurCtx.filter = `blur(${blurRadius}px)`;
      tempBlurCtx.drawImage(tempCanvas, 0, 0);

      // Start with the blurred layer on our stroke canvas
      strokeCtx.drawImage(tempBlurCanvas, 0, 0);
      // Use 'overlay' to blend the original texture (high-frequency) back in.
      // The 'brushStrength' controls the intensity of this texture blend.
      strokeCtx.globalCompositeOperation = 'overlay';
      strokeCtx.globalAlpha = brushStrength / 20; 
      strokeCtx.drawImage(tempCanvas, 0, 0);
      
      // Reset for next operations
      strokeCtx.globalCompositeOperation = 'source-over';
      strokeCtx.globalAlpha = 1.0;
    }

    // STEP 2: Create a soft circular mask and apply it to the stroke.
    // This makes the brush have soft edges instead of a hard circle from clip().
    strokeCtx.globalCompositeOperation = 'destination-in';
    const gradient = strokeCtx.createRadialGradient(
      brushRadiusOnCanvas, brushRadiusOnCanvas, 0,
      brushRadiusOnCanvas, brushRadiusOnCanvas, brushRadiusOnCanvas
    );
    gradient.addColorStop(0.5, 'rgba(0,0,0,1)'); // Inner part of brush is fully opaque
    gradient.addColorStop(1, 'rgba(0,0,0,0)');   // Edge fades to transparent
    strokeCtx.fillStyle = gradient;
    strokeCtx.fillRect(0, 0, sWidth, sHeight);
    strokeCtx.globalCompositeOperation = 'source-over';

    // STEP 3: Draw the final, prepared stroke onto the main canvas,
    // respecting the global brush opacity.
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.globalAlpha = brushOpacity / 100;
    ctx.drawImage(strokeCanvas, sx, sy);
    ctx.globalAlpha = 1.0;
    
  }, [isDrawing, brushSize, brushStrength, brushMode, brushOpacity, zoom]);

  const startDrawing = useCallback((event: React.MouseEvent | React.TouchEvent) => {
    event.preventDefault();
    setIsDrawing(true);
    const nativeEvent = 'touches' in event.nativeEvent ? event.nativeEvent.touches[0] : event.nativeEvent;
    draw(nativeEvent);
  }, [draw]);

  const stopDrawing = useCallback(() => {
    setIsDrawing(false);
  }, []);

  const handleMouseDown = (event: React.MouseEvent) => {
    if (event.button === 1 || isSpacePressed) {
      setIsPanning(true);
      lastPanPoint.current = { x: event.clientX, y: event.clientY };
    } else if (event.button === 0) {
      startDrawing(event);
    }
  };

  const handleMouseMove = (event: React.MouseEvent) => {
    if (isPanning) {
      const dx = event.clientX - lastPanPoint.current.x;
      const dy = event.clientY - lastPanPoint.current.y;
      setPan(p => ({ x: p.x + dx / zoom, y: p.y + dy / zoom }));
      lastPanPoint.current = { x: event.clientX, y: event.clientY };
    } else {
      draw(event.nativeEvent);
    }
  };
  
  const handleMouseUp = () => {
    setIsPanning(false);
    stopDrawing();
  };

  const handleZoom = (factor: number) => {
    setZoom(prev => Math.max(0.2, Math.min(prev * factor, 8)));
  };

  const handleWheel = (event: React.WheelEvent) => {
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.1 : 1 / 1.1;
    handleZoom(factor);
  };
  
  const resetZoomAndPan = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleApplyClick = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      onApply(canvas.toDataURL('image/png'));
    }
  };
  
  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-90 z-50 flex flex-col items-center justify-center p-4">
      <div className="absolute top-4 right-4 md:top-6 md:right-6 lg:right-auto lg:left-4 z-50 w-full max-w-xs p-4 bg-gray-800 rounded-2xl shadow-lg space-y-2">
        <h3 className="text-lg font-bold text-center text-gray-200">Touch Up Tools</h3>

        <div className="pt-2">
            <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider text-center mb-2">View</h4>
            <div className="grid grid-cols-3 gap-2">
                <Button onClick={() => handleZoom(1.25)} variant="secondary" size="small" aria-label="Zoom In" title="Zoom In (Scroll Up)"><ZoomInIcon className="h-4 w-4 mx-auto" /></Button>
                <Button onClick={() => handleZoom(1/1.25)} variant="secondary" size="small" aria-label="Zoom Out" title="Zoom Out (Scroll Down)"><ZoomOutIcon className="h-4 w-4 mx-auto" /></Button>
                <Button onClick={resetZoomAndPan} variant="secondary" size="small" aria-label="Reset View" title="Fit image to view"><ZoomFitIcon className="h-4 w-4 mx-auto" /></Button>
            </div>
        </div>
        
        <div className="pt-2 space-y-4">
            <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider text-center mb-2">Brush</h4>
            <div className="p-1 bg-gray-700 rounded-lg grid grid-cols-2 gap-1">
                <button 
                    onClick={() => setBrushMode('clarify')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors w-full ${brushMode === 'clarify' ? 'bg-purple-600 text-white shadow-sm' : 'text-gray-300 hover:bg-gray-600'}`}
                    title="Texture-preserving smoothing. Good for skin."
                >
                    Clarify
                </button>
                <button
                    onClick={() => setBrushMode('smooth')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors w-full ${brushMode === 'smooth' ? 'bg-purple-600 text-white shadow-sm' : 'text-gray-300 hover:bg-gray-600'}`}
                    title="Standard blur smoothing."
                >
                    Smooth
                </button>
            </div>
            <AdjustmentSlider label="Brush Size" value={brushSize} onChange={setBrushSize} min={10} max={100} tooltip="Set the diameter of the brush." />
            <AdjustmentSlider label="Brush Opacity" value={brushOpacity} onChange={setBrushOpacity} min={0} max={100} tooltip="Control the transparency of each brush stroke." />
            <AdjustmentSlider 
              label={brushMode === 'smooth' ? 'Strength' : 'Texture'} 
              value={brushStrength} 
              onChange={setBrushStrength} 
              min={1} 
              max={20} 
              tooltip={brushMode === 'smooth' ? 'Set the intensity of the blur effect.' : 'Control how much original texture is preserved.'}
            />
        </div>
        
        <div className="pt-2 space-y-4">
            <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider text-center mb-2">Image</h4>
            <AdjustmentSlider label="Image Blur" value={blur} onChange={setBlur} min={0} max={20} tooltip="Apply a global blur to the entire image." />
        </div>

        <div className="flex gap-3 pt-2">
            <Button onClick={handleApplyClick} size="small" title="Save changes and close the editor.">Apply</Button>
            <Button onClick={onCancel} variant="secondary" size="small" title="Discard changes and close the editor.">Cancel</Button>
        </div>
      </div>
      
      <div 
        className="w-full h-full flex items-center justify-center overflow-hidden" 
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        <canvas
          ref={canvasRef}
          className="max-w-none rounded-lg shadow-2xl"
          style={{
            transform: `scale(${zoom}) translate(${pan.x}px, ${pan.y}px)`,
            cursor: isSpacePressed || isPanning ? 'grab' : 'crosshair',
            transition: 'transform 50ms ease-out',
          }}
          onMouseDown={handleMouseDown}
          onTouchStart={startDrawing}
          onTouchEnd={stopDrawing}
          onTouchMove={(e) => draw(e.nativeEvent.touches[0])}
        />
      </div>
    </div>
  );
};
