
import React from 'react';

interface AdjustmentSliderProps {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  tooltip?: string;
}

export const AdjustmentSlider: React.FC<AdjustmentSliderProps> = ({
  label,
  value,
  min = 0,
  max = 200,
  step = 1,
  onChange,
  tooltip,
}) => {
  return (
    <div className="w-full" title={tooltip}>
      <label htmlFor={label} className="flex justify-between items-center text-sm font-medium text-gray-400 mb-2">
        <span>{label}</span>
        <span className="bg-gray-700 text-gray-200 text-xs font-mono py-0.5 px-2 rounded">{value}{label.toLowerCase().includes('size') || label.toLowerCase().includes('blur') ? 'px' : '%'}</span>
      </label>
      <input
        id={label}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value, 10))}
        className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer range-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500"
        aria-label={`${label} slider`}
      />
    </div>
  );
};
