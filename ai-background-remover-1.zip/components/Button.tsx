import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  isLoading?: boolean;
  variant?: 'primary' | 'secondary';
  size?: 'normal' | 'small';
}

export const Button: React.FC<ButtonProps> = ({ children, isLoading, variant = 'primary', size = 'normal', ...props }) => {
  const primaryClasses = "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 focus:ring-indigo-500";
  const secondaryClasses = "bg-gray-600 hover:bg-gray-500 focus:ring-gray-400";
  const sizeClasses = size === 'small' ? 'px-3 py-2 text-sm' : 'px-6 py-3 text-base';
  
  return (
    <button
      {...props}
      className={`w-full flex items-center justify-center border border-transparent font-medium rounded-md shadow-sm text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 ${sizeClasses} ${variant === 'primary' ? primaryClasses : secondaryClasses}`}
    >
      {children}
    </button>
  );
};