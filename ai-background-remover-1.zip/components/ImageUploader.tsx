
import React, { useRef, useCallback } from 'react';
import { UploadIcon } from './icons';

interface ImageUploaderProps {
  onFileSelect: (file: File) => void;
  imageUrl: string | null;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onFileSelect, imageUrl }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  const onDragOver = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
  };

  const onDrop = (event: React.DragEvent<HTMLLabelElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
        onFileSelect(file);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full flex flex-col items-center">
      <h2 className="text-2xl font-bold text-gray-300 mb-4">Original Image</h2>
      <div className="w-full aspect-square bg-gray-800 rounded-2xl shadow-lg border-2 border-dashed border-gray-600 flex items-center justify-center relative overflow-hidden transition-all duration-300 hover:border-purple-500 hover:bg-gray-700">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        <label
          onClick={openFileDialog}
          onDragOver={onDragOver}
          onDrop={onDrop}
          className="w-full h-full flex flex-col items-center justify-center cursor-pointer p-4"
        >
          {imageUrl ? (
            <img src={imageUrl} alt="Original" className="max-w-full max-h-full object-contain rounded-lg" />
          ) : (
            <div className="text-center text-gray-500">
              <UploadIcon className="mx-auto h-12 w-12" />
              <p className="mt-2 font-semibold">Click to upload or drag & drop</p>
              <p className="text-sm">PNG, JPG, GIF up to 10MB</p>
            </div>
          )}
        </label>
      </div>
    </div>
  );
};
