
import { GoogleGenAI, Modality } from "@google/genai";

// Assume process.env.API_KEY is available in the environment.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real application, you might want to handle this more gracefully.
  // For this environment, we rely on the key being set externally.
  throw new Error("API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const removeBackground = async (
  base64ImageData: string,
  mimeType: string
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: 'Remove the background of this image. Make the background transparent. The output must be a PNG image with a transparent background.',
          },
        ],
      },
      config: {
        // Must include both Modality.IMAGE and Modality.TEXT
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    // Find the image part in the response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData && part.inlineData.mimeType.startsWith('image/')) {
        return part.inlineData.data;
      }
    }

    // If no image is found, check for a text response that might indicate an error
    const textResponse = response.text?.trim();
    if (textResponse) {
        throw new Error(`API returned a text response instead of an image: ${textResponse}`);
    }

    throw new Error('No image was returned from the API.');
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to remove background: ${error.message}`);
    }
    throw new Error('An unknown error occurred while removing the background.');
  }
};

export const enhanceFace = async (
  base64ImageData: string,
  mimeType: string
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: 'Subtly enhance the primary face in this image. Improve lighting, sharpen details, and reduce minor blemishes for a natural, professional look. Do not alter the person\'s features or the transparent background. The output must be a PNG image with a transparent background.',
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData && part.inlineData.mimeType.startsWith('image/')) {
        return part.inlineData.data;
      }
    }

    const textResponse = response.text?.trim();
    if (textResponse) {
        throw new Error(`API returned a text response instead of an image: ${textResponse}`);
    }

    throw new Error('No image was returned from the API.');
  } catch (error) {
    console.error("Error calling Gemini API for face enhancement:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to enhance face: ${error.message}`);
    }
    throw new Error('An unknown error occurred during face enhancement.');
  }
};
